#ifndef MBX_DEFAULT_H
#define MBX_DEFAULT_H
#include <stdbool.h>

#include "../../mojibake.h"

bool mbx_default(mojibake_target_t *target, unsigned int index, void *arg);
#endif
